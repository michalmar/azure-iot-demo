﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ASACloudDeserializerApplication
{
    public class Class1
    {
        // Public static function
        //public static Int64 SquareFunction(Int64 a)
        //{
        //    return a * a;
        //}
    }
}
